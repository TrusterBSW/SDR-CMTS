# Tests à effectuer : émetteur downstream (état actuel)

Banc **fermé uniquement**. Aucune liaison avec la prise du réseau d'origine pendant ces tests.

## Matériel
- B210 et son câble USB 3 ; PC Linux
- Modem d'opérateur et son alimentation
- Un atténuateur 8 dB, deux coupleurs (répartiteurs) 1 vers 2 et des adaptateurs SMA ↔ F
- HackRF (ou RTL-SDR) pour observer, avec gqrx ou SDR++

## Raccordement
```
B210 [TX/RX] ── coupleur A [entrée] ──┬── sortie 1 ── modem (entrée câble)
                                      └── sortie 2 ── 8 dB ── coupleur B ── HackRF / RTL-SDR
PC Ethernet ── modem (pour lire http://192.168.100.1)
```
Le port RX2 du B210 reste libre. Aucun récepteur ne doit être sur la même branche que le modem
sans passer par l'isolation du coupleur A et l'atténuateur 8 dB : les bursts du modem peuvent atteindre +8 dBm.

---

### T0 : préparation (modem branché sur la ligne d'origine, AVANT le banc)
- **But :** relever la fréquence downstream habituelle du modem.
- **Action :** ouvre `http://192.168.100.1` et note la fréquence downstream, la puissance (dBmV), le SNR et la modulation.
- **Attendu :** une fréquence vers 300–800 MHz, sur la grille de 8 MHz. Elle servira dans `--freq`.
- Débranche ensuite le modem du réseau d'origine.

### T1 : performance du PC
```bash
cd ~/claude/Docsis
python3 ds_tx.py --bench
python3 ds_tx.py --bench --qam 256
```
- **Attendu :** plus de `1.2x real time` dans les deux cas.
- **Sinon :** ferme les autres applications et règle le gouverneur CPU en performance (`sdr_cmts.py --performance` le fait le temps du lancement).

### T2 : tests logiciels
```bash
python3 tests/test_phy_vs_grdtv.py
python3 tests/test_loopback.py 64
python3 tests/test_loopback.py 256
```
- **Attendu :** `equal: True` (deux fois), puis `packets equal to transmitted: 1.0000` et `HCS status 1` sur tous les messages.

### T3 : détection du B210
```bash
uhd_find_devices
uhd_usrp_probe | head -40
```
- **Attendu :** un `B210` trouvé, connecté en USB 3 (le probe indique `Operating over USB 3`).
- Au premier lancement, le firmware se charge (quelques secondes).

### T4 : signal à vide, sans modem
- **Raccordement :** B210 → 30 dB → HackRF uniquement.
- **Actions :**
  ```bash
  python3 ds_tx.py --freq 474e6 --gain 40
  ```
  En parallèle, dans gqrx sur le HackRF : fréquence 474 MHz, bande ≥ 10 MHz, gain LNA bas.
- **Attendu :**
  - un plateau plat d'environ 8 MHz de large, centré sur 474 MHz, avec des flancs raides ;
  - pas de raie au centre (fuite LO faible) ;
  - côté console : un message de statut toutes les 5 s, `queue=` stable autour de 10–16, **aucun `U`**.
- **Problèmes :** des `U` réguliers signalent un problème CPU ou USB (refais T1, change de port USB 3). Une raie forte au centre est normale à faible gain ; elle n'empêche pas le verrouillage.

### T5 : verrouillage du modem en 64-QAM
- **Raccordement :** le montage complet ci-dessus.
- **Action :**
  ```bash
  python3 ds_tx.py --freq <fréquence notée en T0> --gain 50
  ```
  Allume ensuite le modem et attends jusqu'à 5 minutes.
- **Attendu :**
  1. Le voyant downstream passe de clignotant à fixe.
  2. La page `192.168.100.1` indique downstream *Locked*, en 64-QAM.
  3. Puissance entre −10 et +10 dBmV, SNR au-dessus de 30 dB.
- **Réglage du niveau :** si la puissance dépasse +10 dBmV, baisse `--gain` ; si elle est sous −10 dBmV, monte-le, par pas de 5 dB. Repère : niveau au modem ≈ gain − 50 dBmV à travers un coupleur 1 vers 2 (±5 dB) ; démarre à `--gain 50`.
- **À noter :** le temps de verrouillage, la puissance, le SNR et le journal d'événements du modem.

> **✅ Résultat validé — 2026-10-07 (Sagem F@st 3686 V1B)**
> - Verrouillage downstream obtenu : voyant passé fixe (brièvement), en 64-QAM.
> - **Fréquence : 306 MHz. Gain : `--gain 49`. Inversion : défaut (spectre inversé), *sans* `--no-invert`.**
> - Raccordement : un seul splitter 1→2 partagé entre le HackRF et le B210.
> - Niveaux non lus dans l'interface web (verrouillage trop bref pour ouvrir la page).
> - Burst de ranging du modem observé au HackRF à **40 MHz** (voir T7) → le modem a lu l'UCD et appliqué la config amont.
> - Lock bref et répété : attendu, aucun récepteur amont ne répond au RNG-REQ, le modem retente puis rescanne.
> - **Conclusion : chaîne descendante J.83A + MAC DOCSIS (SYNC/UCD/MAP) + inversion validée de bout en bout contre un vrai modem.**

### T6 : synchronisation DOCSIS (SYNC, UCD, MAP)
- Se fait dans la suite de T5, sans rien changer.
- **Attendu :**
  - pas d'erreur *T1 timeout* (SYNC/UCD) ni *SYNC timing synchronization failure* dans le journal ;
  - le voyant upstream se met à clignoter ;
  - le statut passe en *ranging* ou équivalent.
- **À noter :** les messages exacts du journal (copie ou photo).

### T7 : bursts du modem visibles
- **Raccordement :** passe le HackRF ou le RTL-SDR à 40 MHz, avec 2 MHz de bande au moins (vue cascade/waterfall).
- **Attendu :**
  - des impulsions courtes (environ 1,6 MHz de large) autour de 40 MHz ;
  - leur niveau monte d'essai en essai : le modem augmente sa puissance faute de réponse ;
  - des *T3 timeout / No Ranging Response* dans le journal : **c'est normal à ce stade** ;
  - au bout d'un moment, le modem peut redémarrer son scan, puis revenir.
- **Optionnel :** enregistre une capture IQ de 10 à 20 s à 40 MHz pour l'analyser plus tard. Garde un gain bas pour ne pas saturer.
  ```bash
  hackrf_transfer -r us_40M.iq -f 40000000 -s 4000000 -n 80000000 -l 16 -g 10
  ```

> **✅ Observé — 2026-10-07 :** burst de ranging du modem visible à 40 MHz au HackRF, consécutif au verrouillage downstream (cf. T5).

### T8 : 256-QAM
```bash
python3 ds_tx.py --freq <fréquence> --gain 50 --qam 256
```
- **Attendu :** même chose qu'en T5–T7, avec la modulation 256-QAM affichée sur la page d'état.
- Le SNR nécessaire est plus élevé : au moins 33 dB.

### T9 : autre fréquence upstream
```bash
python3 ds_tx.py --freq <fréquence> --us-freq 60e6
```
- **Attendu :** les bursts se déplacent vers 60 MHz.
- Cela confirme que le modem suit bien l'UCD.

### T10 : stabilité (≥ 10 minutes)
- Laisse tourner T5 pendant plus de 10 minutes.
- **Attendu :** pas de `U`, le downstream reste verrouillé.
- **À surveiller vers 7 minutes (419 s) :** le compteur d'horodatage repart à zéro. Note si le modem perd la synchronisation à ce moment-là.

---

## Surveillance du banc avec le 2e B210 (`lab_monitor.py`)

Le 2e B210 écoute le coax du labo et décode en continu le downstream de **ton** CMTS. Il affiche
des diagnostics et écrit **tout** dans un pcap pour Wireshark : données, messages unicast et
messages diffusés. Ce n'est le cas que si la source des SYNC est ton CMTS (`--lab-mac`, 02:00:00:ca:fe:01 par défaut).

### Raccordement
```
B210 n°1 [TX/RX] ── coupleur A [entrée] ──┬── sortie 1 ── modem
                                          └── sortie 2 ── 8 dB ── coupleur B [entrée] ──┬── B210 n°2 [RX2 / « RXA »]
                                                                                         └── HackRF (upstream, 40 MHz)
```
Avec deux B210 sur le même PC, chaque commande doit viser son appareil :
```bash
uhd_find_devices                     # relever les deux numéros de série
python3 ds_tx.py --args type=b200,serial=<SERIE_TX> --freq 474e6 --gain 50
python3 lab_monitor.py --args serial=<SERIE_RX> --freq 474e6 --gain 50 --pcap captures/labo.pcap
wireshark captures/labo.pcap         # filtre utile : docsis_mgmt
```
Branche si possible les deux B210 sur deux contrôleurs USB 3 différents.

### T11 : le moniteur voit le signal (avant d'allumer le modem)
- **Attendu au lancement :** `niveau d'entrée` entre 0,05 et 0,5. Ajuste `--gain` si le script signale une saturation ou un niveau trop faible.
- **Attendu à chaque bloc :**
  - MER au-dessus de 35 dB, `spectre inversé` (ou `normal` si `ds_tx.py --no-invert`) ;
  - `RS en erreur 0.00 %`, `CC err 0`, `SYNC/10.0x ms` ;
  - gigue SYNC de l'ordre de 100 ns, et `horloge x1.000000` à ±0,000005 près (la norme impose ±5 ppm) ;
  - trames : `MAP` et `SYNC` à chaque bloc, `UCD` environ une fois par seconde.

### T12 : modem allumé
- Garde `lab_monitor.py` en marche pendant T5 à T7. Le pcap enregistre tout ce que ton CMTS émet.
- Si le modem ne verrouille pas alors que T11 est bon, compare dans Wireshark les SYNC, UCD et MAP de `captures/labo.pcap` avec ceux du réseau d'origine (`captures/origin282_mgmt.pcap`).
- `--save-iq captures/iq` garde aussi les blocs IQ bruts pour une analyse ultérieure. Prévois de l'espace : environ 80 Mo par bloc de 0,5 s.

---

## Étape 3 : upstream et ranging (`sdr_cmts.py`, un seul B210)

Montage (voir README, section « Étape 3 ») :
```
B210 TX/RX ── coupleur A [entrée] ──┬── sortie 1 ── modem
                                     └── sortie 2 ── 8 dB ── coupleur B [entrée] ──┬── B210 RX2
                                                                                    └── HackRF (60 MHz, amp. OFF)
```
La rafale du modem atteint RX2 par l'isolation du coupleur A : environ −17 dBm au pire. Ne mets pas le modem sur l'entrée du coupleur A.
Ordre : lance le programme, puis allume le modem. Pour arrêter, éteins le modem d'abord, puis Ctrl-C.

### T13 : tests sans matériel
```bash
python3 tests/test_upstream_phy.py
python3 tests/test_ranging_sim.py
python3 tests/test_im_overlap.py
```
- **Attendu :** `PASS` trois fois. Le second affiche 6 scénarios `OK`, avec un *success* vers 0,1 s.

### T14 : démarrage sans modem
```bash
python3 sdr_cmts.py --freq 306e6 --gain 49
```
- **Attendu :** une ligne `master clock 27.808000 MHz | TX … | RX 3.476000 MS/s @ 60.0000 MHz (LO 63.0 MHz)`,
  sans message `!!`. Ensuite, toutes les 5 s : `U 0 L 0 O 0`, et un bruit RX stable (vers −60 / −75 dBFS selon `--us-gain`).
- Avec le HackRF à 60 MHz, les rafales du modem doivent apparaître à 60 MHz, et plus à 40 MHz : le modem suit l'UCD.
- Si la ligne affiche `!!`, note le message exact.

### T15 : écoute seule, le modem émet ses RNG-REQ
```bash
python3 sdr_cmts.py --freq 306e6 --gain 49 --us-gain 10 --no-rsp --save-bursts captures/bursts
```
Allume le modem.
- **Attendu :** après le verrouillage downstream, des séries de lignes `[US] RNG-REQ <MAC du modem> IM SID 0x0000 …`
  (écoute seule). La puissance (dBFS) monte d'une ligne à l'autre. Sans réponse, le modem abandonne, rescanne
  le downstream (quelques secondes à quelques dizaines de secondes), puis recommence une série.
- **Réglage de `--us-gain` :** les plus fortes rafales d'une série doivent arriver vers −20 dBFS. Si elles restent bien
  en dessous, relance avec +10. Si `SATURATION ADC` apparaît, baisse-le. Garde cette valeur pour T16 : le CMTS
  ordonne au modem d'arriver à −20 dBFS, donc un gain trop bas le ferait émettre plus fort que nécessaire.
- **À noter :** les mentions `octets LSB-first` ou `spectre inversé` si elles apparaissent, la MER et
  les éventuelles lignes `rafale … non décodée`. Garde le dossier `captures/bursts` si des rafales restent non décodées.

### T16 : ranging
```bash
python3 sdr_cmts.py --freq 306e6 --gain 49 --us-gain <valeur réglée en T15>
```
- **Attendu :**
  1. `RNG-REQ … IM` puis `RNG-RSP continue` (correction de temps, puissance et fréquence) ;
  2. `RNG-REQ … SM SID 0x0001`, puis `RNG-RSP success` et `RANGING TERMINÉ` ;
  3. une `RNG-REQ SM` par seconde, toujours en *success* ;
  4. `à l'antenne … ms après la rafale` doit rester **sous 200 ms** ;
  5. ensuite, des lignes `REQ SID 0x0001 : N mini-slots demandés` : le modem tente DHCP. On ne lui accorde
     pas encore de bande, il finira donc par redémarrer : **c'est normal à cette étape**.
- Sur la page du modem (si elle est joignable) : upstream verrouillé et ranging terminé, puis DHCP en cours ou en échec.
- **À noter :** le premier `TA` (retard aller-retour du banc), la puissance d'émission annoncée par le modem et son journal.

### T17 : stabilité (5 minutes)
- Laisse tourner T16.
- **Attendu :** le modem reste en *success* et `U 0`. Pas de `Station Maintenance sans réponse, modem oublié`.

## À me rapporter
| Test | OK / KO | Notes : puissance, SNR, messages du journal, captures |
|---|---|---|
| T1 | | |
| T2 | | |
| T3 | | |
| T4 | | |
| T5 | | |
| T6 | | |
| T7 | | |
| T8 | | |
| T9 | | |
| T10 | | |
| T11 | | |
| T12 | | |
| T13 | OK (2026-10-09) | `test_upstream_phy` PASS (0 faux décodage sur bruit), `test_ranging_sim` PASS (7 scénarios, dont Sagem 183 µs d'avance : success à 0,098 s), `test_real_bursts` PASS (3/3 rafales réelles du Sagem) |
| T14 | OK (2026-10-08) | 27,808 MHz, RX 3,476 MS/s @ 60 MHz (LO 63), bruit −65 dBFS à `--us-gain 30`, TX horodaté bloc par bloc validé sur le FPGA LibreSDR : 6 lancements, `U 0 L 0` en régime établi ; 2 fois sur 6, un à-coup au démarrage seulement (U 1, L 1 à 9 = jusqu'à ~25 ms de downstream jeté, sans décalage), modem encore éteint à ce moment |
| T15 | OK (2026-10-08, 2e essai) | 51/51 RNG-REQ décodées (Sagem 24:7f:20:a8:38:b8, RNG-REQ v1, SID 0), LSB-first, spectre normal. Arrivée −174,1 à −174,5 µs (avant l'IM), +240 Hz, MER 27–32 dB, bruit −70 dBFS à `--us-gain 20`. Le modem balaie sa puissance par pas de ~5 dB sur ~42 dB (−42 à 0 dBFS), seule la plus forte sature. Filtre adapté OK (spectre ±800 kHz, −60 dB au-delà ; MER identique pour α 0,18/0,25). Encore U 12 / L 487 sans priorité temps réel. |
| T16 | OK (2026-10-09), avec un bug corrigé ensuite | Priorité `SCHED_RR 50` (via `prlimit`). IM : arrivée −174,2 µs, −21,7 dBFS, +355 Hz → `RNG-RSP continue TA -1784 P +1.75 dB F -355 Hz`. 1er SM : +0,08 µs, −20,1 dBFS → **success**, `RANGING TERMINÉ`. Puis 1 SM/s en success (±0,07 µs, −20,1 dBFS, MER 26–32 dB), RNG-RSP à l'antenne 54–61 ms après la rafale. REQ SID 1 de 77 mini-slots (DHCP). Rafale U 2 / L 11 isolée à t = 13,3 s, puis plus rien. **Bug à t = 25 s** : SM placé 2 ms après le début de l'IM, donc dans la marge `--im-slack-us` → mesuré contre l'IM, TA +2000 µs envoyé, modem oublié. Corrigé dans `cmts/upstream.py` (la marge IM ne prend plus une rafale située dans un grant unicast) et `cmts/ranging.py` (garde-fou), test `tests/test_im_overlap.py`. À relancer pour T17. |
| T17 | essai 1 (2026-10-09, 68 s, arrêté avant 5 min) | Correctif IM/SM validé : des SM tombés à +1988 µs du début de l'IM sont bien mesurés en SM, aucun `modem oublié`, modem `ranged` tout du long (±0,05 µs, −20 dBFS, MER 27–32 dB, RNG-RSP 54–65 ms). **Problème : U 9 / L 239**, par salves toutes les 5 à 15 s, dont la plus grosse (~220 L, soit ~32 ms de downstream : un `L` = un paquet USB de 2040 échantillons, 0,147 ms) vers t = 51 s. Après chaque salve, la puissance du modem saute de ±5 à 7 dB (−14,5 / −27 dBFS) et 2 rafales SM arrivent à −40 dBFS non décodées. Cause probable : l'IRQ USB du B210 (xHCI 00:14.0, IRQ 135) est traitée uniquement sur le CPU 0 ; nos threads SCHED_RR y affament ksoftirqd/0 (priorité normale). Correctif : `--cpus auto` (par défaut) écarte les CPU 0 et 4 ; lancer avec `--performance` (gouverneur `performance` le temps du lancement).<br>**Essai 2 (2026-10-09, 388 s, `--cpus auto`) :** U 4 / L 197 (0,5 L/s contre 3,4 L/s à l'essai 1), 556 rafales toutes décodées, modem `ranged` à l'arrêt (+0,04 µs, −20,4 dBFS, MER 29–30 dB, RNG-RSP 55–57 ms). Mais SID 0x0002 : le CMTS a oublié le modem une fois (16 SM sans réponse) puis l'a recalé ; cause (salve TX ou redémarrage du modem faute de DHCP) inconnue, log complet non conservé. Non validé : à refaire avec `--pcap` et `tee`.<br>**Essai 3 (2026-10-09) :** le modem répond parfaitement jusqu'à t = 213,5 s (−0,035 µs, −19,9 dBFS, MER 31,7 dB), puis se tait ~14 s ; 16 SM sans réponse → `modem oublié` ; il revient en IM avec SID 0 à t = 227,8 s (−174,9 µs, comme au démarrage), `success` dès le 1er SM, SID 0x0002, et ses REQ recommencent aussitôt (227,96 → 232,96 → 241,96 s : écarts de 5 puis 9 s, le recul exponentiel d'un DHCP DISCOVER). **U/L inchangés (U 2 L 172) de 00:30:23 à 00:31:03** : la perte n'est pas due au TX. Cause la plus probable : le modem réinitialise sa couche MAC après l'échec de son DHCP (attendu tant qu'il n'y a pas de grants de données ; à confirmer dans son journal d'événements). Ranging : stable et reprise automatique OK. Reste ouvert : U 2 / L 172, survenus avant 00:30:23.<br>**Essai 4 (2026-10-09) :** U 0 L 0 pendant 50 s, puis une seule perte de ~26 ms de downstream (U 1, L 176) juste après t = 50,8 s ; ensuite puissance du modem −14,3 / −31,4 dBFS et MER 15,9 dB pendant ~3 s, recorrigés. Même instant (~51 s) que le plus gros blocage de l'essai 1 → déclencheur probablement déterministe. GC Python écarté (aucune collecte complète en 60 s simulées, 81 k objets). Chien de garde ajouté pour l'identifier.<br>**Essai 5 (2026-10-09, `captures/t17.log` + `t17.pcap`, 60 s) :** une seule perte, U 1 / L 136 = **20 ms** de downstream vers t ≈ 51,5 s, **sans pause > 25 ms du thread principal** ; aucun bridage thermique, limites RAPL 64/64 W. pcap : 50 RNG-REQ→RSP en 51,6–63,9 ms (médiane 55,5), 46 success / 4 continue (dont P −5,25 puis +7 dB juste après la perte) ; REQ par séries de 17 (1 + 16 reprises) espacées de 5, 9, 17 s = DHCP DISCOVER sans grant. Cause retenue : la seule réserve contre un retard du thread d'envoi était ce qu'UHD avait déjà passé à l'USB (16 trames par défaut, quelques ms). Ajouté : `--tx-frames 256` (réserve 37,6 ms, latence RNG-RSP attendue ~90 ms), marge TX mesurée (ligne d'état `marge TX min`), L convertis en ms.<br>**Essai 6 / T17b (2026-10-09, 25 min, `--tx-frames 256`) : OK.** U 1 / L 35 = 5 ms en tout, une seule fois (t = 1022 s : le thread `worker` a tenu le GIL ~30 ms, chien de garde en retard de 31 ms). Plus de perte vers 51 s. Marge TX min ~36 ms (un creux à 17 ms sans perte). Le modem se réinitialise toutes les ~2,5 min (SID 1 → 8) faute de DHCP : attendu avant l'étape 4. |
| T18 | OK (2026-10-09) | `test_registration.py` (avec le vrai REG-REQ du Sagem) et `test_provision_tap.py` : PASS |
| T19 | en cours (2026-10-09) | Grants OK (le modem émet exactement dans son grant de 77 mini-slots, MER 30–32 dB). 1er essai : DHCP DISCOVER non décodé, car le modem complète son dernier bloc RS par des zéros jusqu'à la fin du grant (220+220+116 octets d'info pour une trame de 553). Décodeur corrigé, 10/10 rafales enregistrées décodées (FCS Ethernet bon).<br>**2e essai : DHCP OK** (DISCOVER→OFFER→REQUEST→ACK 10.10.0.10, mais le modem n'a répondu qu'au 4e OFFER, les 4 étant identiques ; cause inconnue), ARP OK, **ToD OK**. TFTP RRQ non décodé : la taille du grant arrivait à 447,9999 symboles (différence de grands flottants), tronquée au lieu d'arrondie → dernier bloc RS faux d'un octet. Corrigé, 6/6 RRQ enregistrées décodées. À relancer. |
| T20 | **OK (2026-10-09, 01:42)** | TFTP « cm.cfg » (100 octets) → REG-REQ 220 octets (TLV 3, 18, 29, 24, 25, 6, 7, 5, 8, 12, 44×3, 57) → REG-RSP ok (SFID 1 montant SID 0x0001, SFID 2 descendant) → **REG-ACK ok → MODEM EN LIGNE**. Capacités annoncées : DOCSIS 2.0 (plafonné 1.1 par le CMTS), concaténation, fragmentation, PHS, BPI+, 16 SID, DCC. Le CMTS MIC paraissait faux : TLV 57 (raison d'initialisation, ajouté par le modem) était à tort dans la liste du MIC ; corrigé, le MIC est correct. Un appareil derrière le modem a pris 10.10.0.11 et envoie des requêtes DNS vers 1.1.1.1 (pas de routage : labo fermé). |
| T22 | OK (2026-10-09) | C = Python sur 600 blocs RS, interpolation −58 dB, suivi QPSK/64-QAM sans erreur ; rafale 1500 o. décodée en 2–3 ms (69 avant), GIL ≤ 1,5 ms |
| T23 | OK (2026-10-09, 02:23) | `--tx-frames 128 --tx-queue 6` : ~4 min en ligne, U 0 L 0, marge TX min 16,3 ms sur 19, latence DS ~41 ms (75 avant). Devenus les défauts. CMTS MIC désormais vu correct. |
| T25 | OK (2026-10-09, après corrections) | 1er essai (fast.com) : 2/3 du montant jeté (concaténation en 0xDC au lieu de 0xF8), RNG-RSP jusqu'à 491 ms derrière les données. Corrigé : 55-59 pings/min arrivent, concaténations découpées. |
| T26 | OK (2026-10-09 03:05) | 256-QAM DS, gain 45 : en ligne ; 40,8 Mbit/s UDP sans perte, ping 0 % de perte ; à 56 Mbit/s la file plafonne à 100 ms et jette l'excédent, modem en ligne. |
| T28 | OK (2026-10-09 03:30) | `--docsis30` (MDD), un canal : REG-REQ-MP → REG-RSP-MP → REG-ACK ok, en ligne en mode 3.0. |
| T29 | OK (2026-10-09 03:37-03:58) | `--ds-channels 2` : RCC acceptée (REG-ACK ok, 4 essais sur 5 ; 1 « Partial Service » canal 2) ; DSID 0x1001 ; ping 20/20 avec tout le trafic forcé sur le canal 2 ; 91,8 Mbit/s DS sans perte, U 0 L 0. |
| T33 | OK (2026-10-10 00:05) | Configuration « débit maximal » (README) : speedtest local **93 Mbit/s DS / 22 Mbit/s US**, fast.com via wifi 78/17 Mbit/s, latence 64 ms à vide / 92 ms en charge. Étapes : 1,1 → 3,7 (grants) → 0,46 (burst 64 Ko, dérive d'horloge) → 9,6 (compensation −4,3 ppm) → 12 (profil 200/200) → 17-22 (C, grants un MAP sur 3). |
| T30 | OK (2026-10-09 03:56) | `--us-mode atdma --us-mod 16qam --us-rate 32` : UCD 29 accepté, en ligne, RNG MER 25,4 dB, rafales de données décodées. |
| T31 | OK (2026-10-09 04:27, après corrections) | `--us-mode atdma --us-mod 64qam --us-rate 32` : table 64-QAM confirmée. 1er essai : 5 % d'échecs (fausses REQ), rafales longues KO en fin de rafale (ISI, MER 24,5 dB), 32 rafales manquées (grappe fusionnée), blocages TX toutes les 31 s (pcap). Après égaliseur + corrections : 4 min à 30 Mbit/s DS, **15 670/15 674 rafales décodées, U 0 L 0, 0 blocage, pcap 960 Mo**. ATDMA 64-QAM à 2,56 Msym/s : MER 33,3 dB, 12 575/12 579. |
| T32 | OK (2026-10-09 04:37) | `--ds-channels 2` + ATDMA 64-QAM 5,12 : 3 min à 86,7 Mbit/s DS (jetées 0) + ~1300 trames/s montantes, U 0 L 0, 10 562/10 569 rafales décodées (bruit montant −48,5 dBFS, MER brute 23,8). 80 Mbit/s vers l'eRouter : ping 0 % de perte, 100 ms. 1 « Partial Service » sur 2 lancements. |
| T34 | OK (2026-10-10 02:18) | `--us-channels 2`, réception large bande (27,808 MS/s, DDC logiciel par canal), MTC pas encore activé : en ligne sur le canal 1 comme avant, ~40 % de CPU par processus montant. `tests/test_usproc.py` : même rafale réelle décodée sur les deux canaux (MER 36,7 dB, instant identique). |
| T35 | OK (2026-10-10 02:38) | Agrégation montante MTC : REG-ACK 209 (reject-bad-tcc) avec le canal 2 à 67 MHz, puis avec le TCC de fenêtre de dynamique ; sans ce TCC et à 53 MHz : ranging du canal 2 (MER 29 dB), REG-ACK ok, **en ligne sur 2 canaux montants**, segments réassemblés (seq 0 sur le canal 1, seq 1 sur le canal 2…), ping 20/20. Débit agrégé non mesuré (pas de client derrière le modem). |
| T36 | partiel (2026-10-10 02:43-03:00) | 3 DS + 2 US : en ligne à chaque essai ; les 3 canaux descendants acquis 1 fois sur 4 (sinon canal 2, parfois 2 et 3). `--tx-dc-cal` (fuite TX −2 à −24 dB) sans effet sur ce taux. |
| T37 | partiel (2026-10-10 02:43-03:41) | 3 DS + 2 US, 19 lancements : toujours en ligne, les 3 DS acquis 6 fois (gain 52 : 1/7 dont 4 calibrés ; 47 : 2/4 ; 44 : 3/4 puis 0/4). Le gain TX ne fait pas de différence nette. |
| T38 | OK (2026-10-10 03:19) | 4 US ATDMA 64-QAM 2,56 Msym/s + 2 DS : 4 canaux rangés, REG-ACK ok, ping 30/30 (91 ms), 2 640 segments réassemblés, 0 perdu, U 0 L 0 ; CPU : émission 150 %, 40-50 % par processus montant. |
| T39 | limite (2026-10-10 03:31-03:34) | 3 DS + 4 US : avec 2 cœurs pour le montant, l'émission décroche (L 3 millions) ; avec 1 cœur (`SDR_CMTS_US_CORES=1`), en ligne avec tous les canaux (1 essai), montant à ~150 ms, ping 40/40 à 258 ms. |
| T40 | OK (2026-10-10 13:33-14:13) | Hôte Proxmox (i5-9500 6 cœurs, sans AVX-512, B210 seul sur le bus USB 3, `--no-irq-herd`), client iperf3 derrière le modem : référence v6 2 DS + 1 US **87/19 Mbit/s** ; code actuel par défaut 86,8/18,6 ; 2 DS + 2 US 86,6/11-12 (processus montants à 100 %) ; 3 DS + 2 US 15-24/13 (émission limitée par le GIL : Python 1,4× plus lent que sur le portable, canal 2 perdu en boucle). Blocages TX+RX de 85 ms et 13 O/62 U en 90 s de `benchmark_rate` à 27,8 MS/s dus aux états C profonds (C10) : 0 O/1 U avec `/dev/cpu_dma_latency` tenu (désormais fait par `--performance`). |
| T41 | OK (2026-10-10 14:57) | `--radio-process` (B210, J.83, mise en forme, émission dans `cmts/radio.py`), Proxmox, 3 DS + 2 US : 15-24 → **129,7 Mbit/s** descendant, U 0 L 0, marge TX ≥ 17,5 ms pendant la charge (avant : ~1 ms, blocages de 66-109 ms, canal 2 perdu en boucle) ; les 3 canaux portent chacun un tiers du trafic. `tests/test_radio.py`. |
| T42 | OK (2026-10-10 15:10-15:35) | Décodage montant optimisé (métrique de préambule en C, DDC/filtre adapté/interpolation AVX2) et dérive d'horloge gardée seulement si elle décode : sans ce dernier correctif, sous envoi, MER de US1 22 → 12 dB et 18 % de rafales perdues. Coax nettoyé (2e modem non alimenté débranché). 3 DS + 2 US : 130,8 / 15,8 Mbit/s, 99,4 % décodées ; **3 DS + 1 US : 130,8 / 20,2 Mbit/s**, ping 93 ms. |
| T43 | analyse (2026-10-10 16:00-16:20) | Pourquoi 2 US < 1 US (3 DS, processus radio). 1 US : 20,7 Mbit/s, 95 retransmissions TCP, 0,2 % de rafales perdues. 2 US : 11,6-17,4 Mbit/s, 347 retransmissions ; US2 perdait 2,7 % de ses grants : le modem n'y émettait pas (captures : seulement le débordement à −38 dBFS d'une rafale US1 simultanée), puissance déclarée 46-49 dBmV par canal. Avec `--us-target -20` (40,75 dBmV) : 0,2-0,8 %, 108-164 retransmissions. Restent : réassemblage en ordre qui attend l'autre canal (moy. 4-70 ms, max 200-760 ms), grants utilisés à 85 % mais ~35 % de la capacité d'un canal : TCP, freiné par ces pertes et à-coups, ne remplit pas la file du modem (requêtes moyennes 7-10 Ko). Les grants en avance sur tous les canaux à la fois (`SDR_CMTS_AHEAD_ALL`) n'y changent rien. Diagnostic `[MTC]` (SDR_CMTS_TIMING). |
| T44 | OK (2026-10-10 16:20-16:40) | Horloge maître et calage du modem, 1 canal : calé en 12-16 s à 20,856 (3 éch./symbole), 27,808 (2 et 4) et 34,76 MHz (5) ; jamais en 150-180 s à 41,712, 48,664, 55,616 MHz, ni en 64-QAM, ni avec `--no-invert` (aucune énergie montante : le modem n'émet pas). Rebouclage B210 (TX 306 MHz → RX2) : porteuse 0 Hz, horloge 0 ppm, MER 21,2 dB identiques de 27,808 à 55,616 MHz. |
| T45 | OK (2026-10-10 16:44-16:54) | **4 DS** à 34,76 MHz, `--radio-process` (une synthèse par canal : avec 2 fils l'émission tombait à 80 % du temps réel) : en ligne, 4 canaux agrégés (le 4e par CM-STATUS), **156,0 / 19,3 Mbit/s**, trafic réparti au quart ; second essai 131,5 / 19,2, les canaux centraux 2-3 (de part et d'autre de l'oscillateur local à 318 MHz) ont décroché 1 à 3 fois par essai. |
| T46 | OK (2026-10-10 21:00-21:30) | **Calage au-delà de 34,76 MHz** : à 41,712 MHz avec un US qui marche (`SDR_CMTS_DECIM=2`), la page du modem dit DS non acquis → c'est l'émission. Lien FPGA ↔ AD9361 à 41,7 MHz écarté (calé à 20,856 MHz en 2R2T, horloge du lien doublée). Rebouclage B210 : image TX (miroir autour de l'OL) à −51 dBc jusqu'à 27,8 MHz, −21 à −24 dBc au-delà avec le filtre RX à 10-12,4 MHz, −51 dBc avec ≥ 20 MHz : la calibration de quadrature TX d'UHD (ton rebouclé par le filtre RX, à l'ouverture des flux) ratait. Flux ouverts avec un filtre RX de 56 MHz puis resserré (`radio.TX_CAL_RX_BW`) : **calé à 41,712 MHz (20 s) et 55,616 MHz (12 s)** ; 4 DS en ligne d'emblée sur les 4 canaux. 5 DS à 55,616 MS/s : le processus radio (218 % CPU) ne suit pas, l'émission prend un retard définitif. |
| T47 | OK (2026-10-10 21:45-22:20) | **Synthèse AVX2** (filtre polyphasé vectorisé sur les phases, 4 symboles à la fois) : 0,51 → 0,09 cœur par canal à 55,6 MS/s sur le Proxmox, identique à numpy à −123 dB ; codage J.83 dans les fils de synthèse ; un fil par 2 canaux (un par canal = 9 fils temps réel sur 4 CPU : décodage montant jusqu'à 220 ms en retard, ping 86-388 ms). **5 DS : en ligne sur 5 canaux, 215,6 / 20,2 Mbit/s, ping 91 ms, U 0 L 0.** 6 DS : SNR 38-39,8 dB sur les 6 canaux (page du modem), 208-209 Mbit/s descendant, mais montant 2,9 Mbit/s, ping 49-1060 ms, canal 6 perdu une fois. Ping de la config de référence (2 DS, un processus) sur le Proxmox : 89-93 ms, minimum 46-49 ms (grants en avance encore actifs). |
| T48 | analyse (2026-10-10 22:15-22:25) | Ping ~92 ms contre 56-72 au README : la sauvegarde v4 (9/10 22 h 29) donne 96 ms sur le Proxmox, la config de référence 89-93 ms. Ping toutes les 50 ms : min 44, moyenne 71 ms ; toutes les 0,5 s : 96 ms. Pas de régression : sans trafic, chaque ping attend un cycle requête → grant, et le MAP qui porte le grant est construit en tête de la file descendante (~36 ms) ; les 56-72 ms avaient été mesurés avec du trafic qui gardait les grants en avance actifs. |
| T49 | partiel (2026-10-10 22:45-23:05) | **5 DS + 2 US** (60 / 53 MHz, 5,12 Msym/s 64-QAM, `--us-target -20`). Réception large bande à l'horloge maître = 445 Mo/s d'USB à 55,616 MHz : réception réduite au plus petit débit qui contient les canaux. 55,616 / 3 : MER US1 14 dB (décimation impaire du FPGA = CIC seul) ; / 2 : MER 26,4 mais 333 Mo/s d'USB, émission en retard, débordement RX, modem oublié. Décimations paires seulement depuis. **5 DS à 48,664 MHz (7 éch./symbole) + 2 US à 24,332 MS/s : en ligne d'emblée, MER US1 27,4 dB, 145,8 / 12,4 Mbit/s** ; les 2 canaux montants portent ~1 Mo/s chacun, mais les processus montants prennent 70-570 ms de retard sous charge (démodulation à 24,3 MS/s, 4,75 éch./symbole). Profilage tenté : le surcoût fait oublier le modem. |
| T50 | partiel (2026-10-10 23:10-23:45) | **6 DS, nouvel essai** : ping 92 ms, 157,7 / 6,7 Mbit/s ; l'émission prend 1 à 6 ms de retard (« retard côté USB / pilote », L jusqu'à 629), canaux 2/3/4/6 perdus et retrouvés, montant bloqué. Écarté : réordonnancement du modem (trafic forcé sur le canal 1 : pareil), CPU moyen (radio 172 % sur 4 cœurs). Essayé sans effet : fils de calcul en priorité temps réel 40 (pire : 34 Mbit/s, modem oublié), blocs de 128 paquets + file 3 (145 / 5,8). Cause non trouvée. **5 DS @48,664 + 2 US, démodulation après DDC /2** (2,38 éch./symbole, MER 35,8 au lieu de 36,7 au test) : processus montants 50 → 29 % CPU, montant 12,4 → 15,8 Mbit/s ; mais radio sur 3 cœurs : émission en retard, modem oublié ; montants sur 1 cœur (radio sur 4) : modem stable, 122 / 8 Mbit/s, retard montant jusqu'à 711 ms. py-spy du processus montant : DDC 43 % du temps actif. |
| T51 | OK (2026-10-11 00:15-01:05) | **Voie montante en C** : égaliseur en AVX2, étiquettes → octets par mots entiers : 3,08 → 2,55 ms par rafale réelle de 16 640 symboles sur le Proxmox. En marche, une rafale de données coûte ~3,9 ms (≈ 6 Ko : le Python autour de la démodulation pèse autant qu'elle) ; sous envoi, chaque processus montant est à ~76 % de son cœur. 5 DS @48,664 + 2 US : 14,4 Mbit/s, radio en retard sur 3 cœurs, modem oublié 7 fois. **4 DS + 2 US : 173 / 21,5-22,3 Mbit/s, modem jamais oublié** (16 flux, 30 s : 21,1 ; ~1,5 Mo/s de données sur chaque canal, 99,8 % des rafales décodées, processus montants 55 %). Grant en avance à chaque MAP : 12 Mbit/s (retard montant 511 ms) ; `--tx-queue 3` : ping 82 ms, montant 21 Mbit/s. Chaque canal montant n'est utilisé qu'à ~43 % : le modem demande ~16 Ko à la fois, ~190 fois/s. |
| T52 | analyse (2026-10-11 01:10-02:00) | **4 DS + 2 US, pourquoi ~22 Mbit/s montants.** Profil du processus montant sous envoi (py-spy, fil de travail occupé 81 %) : DDC 15 %, filtre adapté 15 %, égaliseur + suivi 14 %, regard « bourrage » de chaque segment 11 %, ajustement d'égaliseur 5 %, RS 7 %. Regard de bourrage réservé aux grants en avance (drapeau `IUC_AHEAD`) : processus 55 → 47 %, attentes de réassemblage moy 1-2 ms. Demandes MTC au-delà de 255 mini-slots : le reste n'était pas accordé (corrigé : accordé aux MAP suivants), mais le modem ne demande en moyenne que 12-18 Ko. Sous envoi : ping 220-840 ms, 242 retransmissions / 18 s ; en traitant les demandes comme additives (essai) : 23,5 Mbit/s, ping 293 ms, mais 176-247 Ko/s de bourrage : le modem laisse des grants vides alors que des données attendent. Conclusion : le Sagem (mode routeur, NAT) ne fait pas passer plus de ~22-24 Mbit/s en montant, avec 1 comme avec 2 US ; la file est avant sa partie DOCSIS. UDP 25 Mbit/s : 12,9 reçus (46 % perdus), à 35 Mbit/s plus rien pendant 2-3 min. |
| T53 | OK (2026-10-11 01:00-01:30) | **Modem en bridge** (case « mode Routeur » décochée, il redémarre seul ; le PC reçoit 10.10.0.12 du CMTS) : 1 US : 17,7-21,1 Mbit/s montants, ping en charge 145 ms (au lieu de ~460 en routeur) ; 4 DS + 2 US : 21,5-22 Mbit/s, ping en charge 300-600 ms, 729 retransmissions : le plafond à 2 US n'est pas le NAT (conclusion de T52 fausse). **Échantillons en 16 bits** : gain négligeable (conversion UHD ~1 % d'un cœur ; le fil d'envoi est surtout noyau). **Trames USB de 16 Ko** (`--args type=b200,send_frame_size=16360 --tx-frames 64`) : fil d'envoi 23 → 16 % d'un cœur à 55,6 MS/s ; **6 DS : plus aucun retard d'émission ni décrochage (U 0 L 0), 204 Mbit/s descendants**, mais montant 6,7-9,9 Mbit/s : le modem demande peu de grants (~50/s), décodage montant à 100 %. 5 DS @48,664 + 2 US : toujours instable. 4 DS + 2 US + trames de 16 Ko : 172 / 20,5 Mbit/s, U 0 L 0. REG-REQ-MP du Sagem : 5.29 (canaux de réception) = 24, 5.24 (canaux d'émission) = 8, 7 profils de réception (TLV 48). |
| T54 | OK (2026-10-11 01:35-01:50) | **Trames USB de 16 Ko par défaut** (`--send-frame-size 16360`, `--tx-frames 64`) : même latence (36 ms) et réserve USB (19 ms), 4 DS + 2 US sans argument : 173 / 21,5-21,9 Mbit/s, U 0 L 0. **Profils de réception du Sagem** (TLV 48 de son REG-REQ-MP) : CLAB-8M-002, -003, -004, -005, -008, -016, -024, modules de 8 canaux adjacents, fréquences centrales 112-1002 MHz ; le CMTS prend le plus petit qui suffit : CLAB-8M-004 en 4 DS, CLAB-8M-008 en 5 et 6 DS. 5 DS marche avec le même profil : ce n'est pas lui qui bloque le montant en 6 DS. |
| T55 | analyse (2026-10-11 01:55-02:40) | **Pourquoi le modem demande peu en 6 DS.** Grants en avance restés vides pendant un envoi : 0-2 % en 4-5 DS, **25-47 % en 6 DS** (le modem n'émet pas dans ces grants, alors que des données attendent ; côté CMTS : 0 débordement RX, décodage 100 %). Sans effet en 6 DS (montant 5,5-12,6 Mbit/s à chaque fois) : avance des MAP 8 et 20 ms (`SDR_CMTS_MAP_LEAD_MS`), canal principal au centre de la bande (`SDR_CMTS_PRIMARY_IDX=2`, 246 Mbit/s descendants), gain d'émission −5 dB, canaux 266-306 MHz au lieu de 306-346 (`--ds-spacing=-8e6`), 5 canaux seulement dans le RCC (`SDR_CMTS_RCC_MAX=5`), puis aussi dans le MDD (`SDR_CMTS_MDD_MAX=5`). La seule présence du 6e signal suffit ; cause encore inconnue. Descendant jusqu'à **258 Mbit/s** en 6 DS. Fichier de configuration : débits max 200 Mbit/s → **1 Gbit/s** dans les deux sens (`provision.py`) ; 4 DS + 2 US : 173 / 21,9-23,4 Mbit/s, U 0 L 0. |
| T56 | OK (2026-10-11 02:45-03:25) | **Idée de l'utilisateur : le canal principal (306 MHz) au milieu**, les autres de part et d'autre (290-330 MHz) : **6 DS : 247 / 20,9 Mbit/s, 0 % de grants vides** (25-47 % avant) ; option `--ds-layout around` : 234 / 21,1 / 21,1 Mbit/s, U 0 L 0. (Le principal à 322 au milieu de 306-346 ne marchait pas : la plage de fréquences compte, cause exacte inconnue.) **6 DS + 2 US** : réception à 27,8 MS/s (334 Mo/s d'USB) + radio sur 3 cœurs : émission en retard, modem oublié 3 fois ; processus montants sur 1 cœur : stable mais retard montant 588 ms, 7-9 / 137 Mbit/s ; 2 US accolés (6,6 MHz) reçus à 13,9 MS/s : US2 perd 5-6 % (bord du filtre FPGA), radio en retard sur 3 cœurs, et sur 4 cœurs le montant à 1 cœur prend 1,6 s de retard. 6 DS + 2 US ne tient pas sur les 5 cœurs utilisables. |
| T57 | OK (2026-10-11 13:50-15:25) | **Défauts : 6 DS `around` + 1 US** (`--ds-channels 6 --ds-layout around --radio-process`) : 20-21 / 244 Mbit/s, ping 98 ms (170 pendant un envoi). **6 DS + 2 US stable.** Charge mesurée (schedstat) : au repos 2,7 cœurs (radio 1,9, MAC 0,3, montants 0,29 chacun). Processus montants à priorité 40 sur les CPU 1-5 (`--us-cpus`, auto en 5-6 DS) : plus de retard d'émission ni de modem oublié, mais 15-17 Mbit/s et retard montant 0,1-2,4 s ; chaque processus montant 72 % occupé + 25 % en attente d'un cœur : un seul fil, saturé. Trames de réception de 16 Ko (`--recv-frame-size`) : fil RX de la radio 24 → 14 %. DDC : réécriture polyphase et filtre demi-bande essayés puis retirés (gain ~0,01 cœur ; le demi-bande seul laissait passer l'autre canal à −6 dB : US2 83 % décodé) ; DDC dans un fil à part (C sans GIL). Contre-réaction (`--us-lag-limit 150`) : plus de grant en avance au-delà de 75 ms de retard, plus de grant de données au-delà de 150 ms. **Rafales collées (MTC) : deux recherches de préambule par rafale** (la première s'arrêtait avant le début du grant, 29 % du processus) → une seule : **6 DS + 2 US : 21,2-22,3 / 230 Mbit/s, retard montant ≤ 152 ms, 99,9 % décodées, U 0 L 0, modem jamais oublié**, ping pendant un envoi ~430 ms (comme 4 DS + 2 US). CFS nice −10 au lieu de la priorité 40 : pire (attente 44 %). |
| T58 | OK (2026-10-11 15:25-16:20) | **Latence descendante** : `--tx-queue 3 --tx-frames 32` (~21 ms au lieu de 36) : ping au repos 100 → 69 ms, mais marge d'émission min 1,2 ms ; `--tx-queue 3 --tx-frames 48` (~25 ms) : ping 78 ms, marge min 6,7 ms, U 0 L 0 ; débit montant inchangé (21-22 Mbit/s en 2 US) : le cycle requête → grant n'est pas ce qui plafonne le montant. **3 / 48 par défaut** depuis (accord de l'utilisateur) ; essai long (30-60 min, U/L, marge) encore à faire. **Descendant** : remplissage des canaux affiché (`remplissage x/x/... %`) : 100 % pendant un téléchargement à 249 Mbit/s. (1) Chaque lot de trames commençait sur un paquet TS et finissait par du bourrage ; 8 paquets par lot = une trame pleine seule sur 9 paquets (~10 % perdus) → 32 paquets : 257-264 Mbit/s. (2) Retransmissions TCP 8 000-13 000 par test (pertes réelles, 32 DSACK seulement) = les trames jetées par l'interface tap cmts0 (file de 1000 trames, ~46 ms, débordée pendant les pauses du lecteur Python) → file de 10 000 : 0 perte au tap, **277-279 Mbit/s en 6 DS + 1 US** ; 6 DS + 2 US : 249-252 / 21 Mbit/s, U 0 L 0. |
| T59 | OK (2026-10-11 16:30-19:30) | **Python restant, mesuré puis réduit (6 DS + 2 US).** Profils py-spy de chaque processus (`profnb.sh`) : en téléchargement CPU 1-5 à 97 % (4,85 cœurs, 247 Mbit/s) ; fabrication des paquets TS (un appel Python par paquet) 32 % au repos / 64 % en téléchargement ; HCS calculé bit par bit ~8 % ; montant : décodage 47 % C / 34 % Python / 18 % numpy. (1) HCS par table : 5,9 → 0,8 µs. (2) Paquets TS : `ts_pack` en C (flux identique bit à bit), un bloc rempli d'un coup, bourrage par séries jusqu'au prochain SYNC/MAP/MDD/UCD (flux identique à l'ancien en simulation) : fil 64 → 33 % en téléchargement, 32 → 20 % au repos. **Mais le descendant tombait à 150-160 Mbit/s** : flux valide (HCS, CRC, séquences complètes, vérifié sur 6 s enregistrées avec `SDR_CMTS_TSDUMP`), pertes hors du CMTS (UDP 0,02-2,4 % de 150 à 280 Mbit/s contre 0 % avec l'ancien multiplexeur) : les files vides, des trames consécutives partaient au même instant sur plusieurs canaux dans le désordre des numéros de canal, et le Sagem en perdait. Trames réparties à tour de rôle (canal suivant, sauf s'il a 3 trames de plus que le moins chargé) : UDP 0 % jusqu'à 250 Mbit/s, **TCP 275-277 Mbit/s**. (3) Porte d'énergie (`block_power` en C), fenêtre lue sans copie : part du fil montant 31 → 25 % (téléchargement), 17 → 13,5 % (envoi), ~0,03 cœur par canal. **Bilan : 269-277 / 23,8-24,3 Mbit/s, CPU 94 % en téléchargement (4,56 cœurs), 90 % en envoi**, ping 78 ms. |
| T60 | OK (2026-10-12 matin) | **Écoute du réseau d'origine, réception seule** (B210 sur RX2 sans atténuateur, coax du réseau d'origine, CMTS arrêté) : MER 36 dB à 282 MHz (gain 40, 16 Méch/s ; HackRF plafonné à 25 dB). Redémarrage du Sagem capturé et décodé (`origin_listen.py`, segments en parallèle sur 6 cœurs) : DHCP, fichier TFTP `fast3686_default.cm` (ligne décommissionnée), REG-RSP-MP (TCC, TLV 47 pour chaque flux montant avec le même SID sur 5 canaux, critères 47.3 à 0, fenêtre de dynamique en TCC action 2, TLV 52), UCD (16-QAM, mini-slot 12,5 µs), MAP (3,2 ms, envoyé ~2,5 ms avant, ack ≈ maintenant − 2,3 ms). CMTS ARRIS (OUI 00:01:5c) aux valeurs d'usine du E6000. `tools/origin_maps.py`. Bogue corrigé : `cmcfg.check` cherchait le CM MIC par motif d'octets. Détails : `PLAN_AGREGATION_US.fr.md`. |
| T61 | OK (2026-10-12 11:00-11:30) | **Enregistrement et requêtes comme le réseau d'origine (6 DS + 2 US).** `--mtc-std` : la TCC de fenêtre de dynamique (obligatoire en MTC selon le MULPI) est **acceptée** par le Sagem sous la forme du réseau d'origine (plus de 209), débit inchangé. `--mtc-owed` : requêtes MTC cumulées (le CM ne demande que les octets nouveaux), grant pending après le Null IE tant qu'il reste dû → montant 22,6 → 27,7 Mbit/s (4 flux). Sans grants en avance : instable. |
| T62 | OK (2026-10-12 11:30-13:00) | **Descendant et récepteur montant en C.** Mesures à 4/8/16 flux : la « baisse » du descendant venait du test à 4 flux (TCP, canaux à 70-80 %) ; 8-16 flux = 266-284 Mbit/s. `--ds-aqm` (CoDel, option) : ping en téléchargement 88 → 55-64 ms, débit inchangé. Profil : processus montants 64 % en C, colle Python ~36 %, CPU 94 %. **Chemin C des segments** (`usdsp.c seg_fast`, égaliseur recalculé en C, identique au Python : `tests/test_seg_fast.py`), 70-78 % des rafales : **6 DS + 2 US = 270-284 / 44-47 Mbit/s** (8 flux), ping au repos 75 ms. |
| T63 | OK (2026-10-12 12:40-14:40) | **Noyaux C et essai long.** Suivi de phase (point de décision sur la grille, phaseur renormalisé tous les 8 symboles) 26 → 19 ns/symbole, mêmes décisions ; syndromes RS en une passe ×4 ; dernier mot raccourci en une passe 39,6 → 7,9 µs. `provision.py --us-buffer` (TLV 24.35, à tester). Blocages USB de 30-58 ms après 13h : le Sagem lâche alors l'US1 et est oublié (aussi avec le code précédent) ; **carte son débranchée + VM 103 arrêtée : disparus**. **Essai long 45 min, 14 cycles : 8 flux 255-282 / 51,3-51,9 Mbit/s, 1 flux 118-174 / 11,7-19,8 Mbit/s**, ping médian 59 ms (p95 179 ms sous charge), un seul blocage USB (US2 mis de côté puis revenu, DS 2 perdu puis retrouvé par CM-STATUS), 0 oubli. |
| T64 | OK (2026-10-12 15:00-15:50) | **TCP sur un flux.** Descendant : les pertes en rafales (~20 paquets, 0,06 %) venaient du **client de test** : carte USB-Ethernet r8152 sur un port USB 2.0 du portable (`rx_missed`), pas du CMTS (5 trames jetées par CoDel) ; en USB 3 : **1 flux = 283 Mbit/s**, 1-7 retransmissions. Montant : `--us-buffer` (TLV 24.35) appliqué par le Sagem : ping pendant un envoi 237 → 89 ms (64 Ko), 93 ms (128 Ko, **nouveau défaut**), 8 flux inchangés (52 Mbit/s) ; 1 flux toujours 12-25 Mbit/s : rafales perdues ~1,3/10 000 (Reed-Solomon dépassé en milieu de segment, surtout sur l'US1 : pas de glissement de phase, mais une bande d'énergie dans le canal 60-64 MHz, 16 dB au-dessus du plancher de l'US2, probablement l'image de l'US2 autour de l'oscillateur local à 56,5 MHz — à traiter). |
| T65 | OK (2026-10-12 15:50-16:40) | **Bruit de l'US1 : le descendant replié par l'oscillateur local de réception.** Avec 2 US, le LO RX est à 56,5 MHz ; sa 5e harmonique (282,5 MHz) replie le canal descendant 286-294 MHz de la disposition 306 « around » dans l'US1 (60 MHz) : bruit −47,6 dBFS au lieu de −60,5. Prouvé : primaire à 314 (298-338 MHz) → −60,5 / −60,6 dBFS sur les deux canaux, rafales perdues ÷2 (0,66 / 10 000). Mais montant 8 flux ~50 Mbit/s contre ~52 à 306 (5 mesures contre 4), envoi 1 flux inchangé : **306 conservé par défaut**. 310 MHz : hors grille européenne, le Sagem ne le trouve jamais. Le 11/10, l'échec de 306-346 venait probablement de la 6e harmonique (339 MHz). Remède propre : filtre passe-bas / diplexeur devant RX2. Ensuite, la carte USB-Ethernet du portable (USB 3) a cessé de recevoir (0 paquet, même après réinitialisation USB) et la prise Home Assistant du modem ne répond plus : banc à vérifier physiquement. |
| T66 | OK (2026-10-14 23:00-00:00) | **Le 2950X (10.5.1.3).** Debian 12 / PVE 8, Python 3.11, UHD 4.3 (images FPGA téléchargées ; FPGA LibreSDR et `uhd.conf` copiés du portable pour JN76WAJ). Deux incompatibilités 3.11 corrigées (f-strings imbriquées, `SharedMemory(track=False)` → `attach_shm`). Les deux B210 en USB 3 sur deux contrôleurs (`benchmark_rate` 15 s à 55,6/27,8 MS/s : 0 et 1 underrun). Un B210 seul en 6 DS ne suit pas (encodeur 90-100 %, émission en retard) : synthèse AVX2 ~2× plus lente par cœur sur Zen+, mémoire sur un seul canal à 2133 MT/s, hyperthreads −25 %, nœud NUMA 1 sans mémoire −29 %. 3 DS : en ligne, marge 15 ms. L'overclock du CPU a planté sous AVX : retiré. |
| T67 | OK (2026-10-15 00:00-01:50) | **Deux B210 : diagnostic.** Avec l'entrée du 1→3 vide, tout passait par l'isolation : signal faible, canaux qui décrochent ; recâblé (modem sur l'entrée). Chaque B210 seul : 94 Mbit/s pour 2 DS, aucune interférence de l'un sur l'autre (bruit de 16 MHz sur l'un, l'autre garde 94). En double : la suiveuse jetait des blocs (anneau de 2 places plein, MAC jamais bloquée par elle) → trous de 1,4 ms dans ses canaux ; anneau de 8 places. **Un démarrage sur deux sans modem** : le récepteur montant prenait son seuil de bruit sur les zéros laissés par le saut du DDC au démarrage (−270 dBFS), ne remontait jamais, et ce canal ne décodait plus rien (le modem au ranging sans réponse, monté à 53 dBmV). Corrigé (`valid_from`, seuil minimal, reprise d'un seuil aberrant) : **5 démarrages sur 5** en ligne en ~70 s. Fausse piste de ma part en cours de nuit : « l'horodatage éteint la suiveuse » venait d'un essai où elle n'avait pas démarré (B210 occupé par mon script de bruit). |
| T68 | OK (2026-10-15 01:55-03:22) | **Dérive des horloges et recalage de la suiveuse, essai de 86 min** (2 + 2 DS, émission horodatée, horloges internes). `tools/clock_drift.py` : Ekard −6,97 ppm, JN76WAJ −4,49 ppm contre l'hôte, **+2,5 ppm relatif = 8,9 ms/h** (une lecture juste après `set_time_now` rendait encore l'ancienne heure : écartée). La suiveuse mesure elle-même +2,35-2,50 ppm et insère un groupe de 8 paquets nuls toutes les ~95 s : 53 groupes, **12,44 ms cumulés**, au-delà de la fenêtre de 10 ms du modem. **Descendant 185-189 Mbit/s** de bout en bout (sauf 137 et 171-175 sur trois mesures tombées pendant un décrochage), montant 46-50, ping 68-73 ms, 0 oubli. 14 pertes de verrouillage, toutes sur un canal de la suiveuse, revenues en ~10 s, chacune juste après un **underflow USB** (marges de 15-19 ms jusque-là : pas un retard du logiciel) ; principale U 7, suiveuse U 15. Cause trouvée ensuite (T69) : la MAC en retard au début de chaque rafale de trafic. |
| T69 | OK (2026-10-15 03:20-05:30) | **Les décrochages au début d'un téléchargement.** Reproduits à coup sûr : 4 min de calme, puis iperf3 descendant → les deux radios bloquées 40-100 ms ensemble, underflow, le modem perd un canal de la suiveuse ~10 s. Écartés par la mesure : priorité des fils `libusb_event` (relevés à 60 : aucun effet), équilibrage NUMA du noyau (coupé : aucun effet), ramasse-miettes de la MAC (aucune pause > 15 ms), iperf3 sur le jumeau du CPU USB (déplacé : aucun effet), lecture de l'heure de l'appareil. Instrumentation de chaque étape (`!! encodeur`, `!! envoi`, `[MAC] !!`, `schedstat` par fil) : les deux encodeurs attendaient **le même bloc** 18-25 ms de la MAC ; le fil `tap` de la MAC tournait 37 ms d'affilée (548 défauts de page) sans attendre de CPU. **Cause** : au démarrage d'un téléchargement, toute la fenêtre TCP de l'émetteur arrive d'un coup dans le TAP ; chaque `os.read` revient aussitôt et le fil `tap` traite des centaines de trames en Python sans jamais dormir, et le fil qui construit les blocs TS, qui relâche le GIL à chaque appel C, ne le récupère qu'aux bascules forcées. En régime établi les lectures attendent (arrivées cadencées par les ACK) : rien. **Correction, trois mesures contre la même cause** (aucune ne suffit seule, essais l11/l12/l14 : 1-2 blocages par rafale) : intervalle de bascule du GIL de 0,5 ms dans la MAC (`SWITCH_INTERVAL_S`), pause de 150 µs du fil `tap` toutes les 32 trames lues sans attente (`bridge.BURST_FRAMES`), et pause de 0,2 ms par trame tant que l'encodeur n'a pas fini de bloc depuis 2 durées de bloc (`start_bridge`). **Ensemble : 7 rafales sur 8 sans blocage** (l13 4/4, l15 3/4 ; 179-189 Mbit/s ; reproduction : `tools/burst_test.sh`), contre 2 blocages à chaque rafale avant ; la 8e : les deux radios bloquées ensemble 66-70 ms (cause non confirmée : le journal limité à une ligne par seconde a pu masquer l'attente de la MAC). Correction de fond à faire : sortir le pont TAP du processus MAC (ou construire les blocs TS sans le GIL). Retirés car sans effet mesuré : priorité des fils libusb, coupure de l'équilibrage NUMA. Reste : de rares retards USB de 14-18 ms sur JN76WAJ (contrôleur du chipset X399), un underflow et une perte de verrou isolés : à essayer sur le contrôleur 43:00.3. |
| T70 | OK (2026-10-15 09:15-20:25) | **bladeRF 2.0 micro en CMTS** (à la place d'Ekard, TX1 / RX1). 3 DS + 1 US à 61,8 MHz : modem en ligne, **138 Mbit/s descendant, 24,5 montant**, ping ~144 ms, MER montant 22 dB. Problèmes résolus dans l'ordre : réception refusée sous 70 MHz (oscillateur à 70 MHz, DDC à −8,2 MHz) ; FPGA 0.16 trop récent pour libbladeRF 2.4.1 (métadonnées mal lues ; FPGA 0.14 chargé en RAM, incompatibilité détectée par le pilote) ; gain RX ignoré avant l'activation du module ; lectures `RX_NOW` trop courtes (lectures contiguës horodatées) ; premiers tampons RX antérieurs au départ (jetés) ; décalage TX/RX faussé par la lecture USB (lecture RX entre deux TX : 2 échantillons) ; gains (TX 50, RX 14 : à 20 le modem était déjà à sa puissance minimale au-dessus de la cible). Émission et réception ont forcément le même débit : en 16 bits, 27,8 MS/s tient, 34,8 / 41,7 / 55,6 non. Fausse piste de ma part : un témoin B210 qui ne voyait pas les signaux larges bande (comparaison à la médiane de la bande) a fait croire à une émission muette ; `bladeRF-cli` et une mesure de puissance absolue ont corrigé. Détails : `docs/BLADERF.fr.md`. |
| T71 | OK (2026-10-15 20:45-21:40) | **Pont TAP hors du chemin critique, ramasse-miettes figé** (2 B210, 2 + 2 DS, 2 US). Le pont lit les trames de Linux par lots en C (`tap_read_batch`) et les PDU sont faites par le fil qui construit les blocs TS, un budget d'octets par bloc (`bridge.TapFeed`) : les trois rustines de T69 retirées. Série de 4 rafales (`tools/burst_test.sh`, 4 min de calme puis iperf3) : 3 sans aucun blocage ; la 4e, les deux radios à sec 73-84 ms derrière **une collecte complète du ramasse-miettes de la MAC (génération 2, 22 ms, 45 554 objets parcourus, aucun libéré)**. Corrigé à la racine : les objets du démarrage figés (`gc.freeze()`, ils vivent jusqu'à la fin), et de nouveau après toute collecte complète lente. Nouvelle série de 4 rafales, par le service du paquet : **0 blocage, 0 pause**, 189/167/189/189 Mbit/s ; 1 perte de verrou sur la suiveuse après un underflow USB sans blocage du programme (JN76WAJ sur le contrôleur du chipset, connu). |
| T72 | OK (2026-10-15 21:10-21:40) | **Paquet Debian et service** (`packaging/build-deb.sh`, `sdr-cmts_1.0.0_all.deb`, 206 Ko) installé par `apt` sur le 2950X (Debian 12, Python 3.11) et le 9500 (Debian 13, Python 3.13) : dépendances résolues, noyaux C compilés par `postinst` pour chaque CPU, service ni activé ni démarré. Deux défauts trouvés par le service et corrigés : UHD refuse de démarrer sans `$HOME` (lecture de `~/.config/uhd.conf`, le FPGA LibreSDR de JN76WAJ) → `Environment=HOME=/root` ; `systemctl stop` envoyait SIGINT à tous les processus, la radio s'interrompait dans UHD (« terminate called ») et la MAC l'attendait jusqu'au SIGKILL de systemd → les processus radio et montants ignorent SIGINT (la MAC les arrête dans l'ordre, ce qui corrige aussi Ctrl+C dans un terminal), `KillMode=mixed`. Banc 2 B210 par le service : en ligne en ~60 s, 4 DS + 2 US, **DS 188-189 Mbit/s** (1 et 16 flux ; 161-167 sur deux mesures à 8 flux, sans incident), **US 49,5** (8 flux), ping 73 ms. **Page d'état** (`--status-http 0.0.0.0:8090`) lue depuis le laptop : canaux et radio de chacun, marges TX, U/L/O, bruit et retard US, modem (état, MER, puissance déclarée, canaux montants), alertes, historique de débit. |
| T73 | OK (2026-10-15 21:45-22:50) | **Effet des options sur le signal, vu par un second B210** (`tools/arg_effects.py` : Ekard émet, JN76WAJ en réception seule sur le même coax balaie 202-450 MHz sans rien savoir, démodule chaque canal et lit ses MDD / UCD). Base 2 DS : 305,8 + 313,9 MHz, 256-QAM, spectre inversé, MER 31-34 dB, MDD 1@306 2@314, UCD 60 MHz 5,12 Msym/s ATDMA 64-QAM. Puis chaque option seule : `--freq 410e6` → 409,7 / 417,7 MHz, MDD 410/418 ; `--ds-channels 3` → 297,8 / 305,8 / 313,9, MDD 1@306 2@298 3@314 ; `--ds-spacing 16e6` → 306 / 322 ; `--ds-layout up` → 306 / 314 / 322 ; `--qam 64` → 64-QAM ; `--gain` −10 dB → niveau −10,0 dB ; `--scale 0.15` → −6,0 dB ; `--no-invert` → spectre non inversé ; `--us-freq 45e6` → UCD à 45 MHz ; `--us-mode tdma --us-mod 16qam --us-rate 16` → UCD TDMA 16-QAM 2,56 Msym/s ; `--us-channels 2 --us-spacing -7e6` → UCD 60 et 53 MHz. **Modem réel** avec le montant annoncé à 45 MHz en TDMA 16-QAM : ranging, REG-ACK, en ligne, MER 37,4 dB, 89/89 rafales décodées. Trouvé en route : `--us-spacing -7e6` refusé par argparse (exposant non reconnu comme nombre négatif ; l'exemple du README l'écrivait ainsi) → corrigé. Le récepteur de test ne se cale pas à chaque fois (deux cas : synchro sur un canal sur deux, et pas de synchro sous −30 dBFS au témoin) : la mesure de fréquence et de niveau reste faite. Arrêts propres vérifiés ensuite : CLI interrompu par `timeout` (deux SIGINT) et `systemctl stop` en 0,6 s, sans traceback ni abandon d'UHD (SIGINT pris une seule fois, B210 libéré avant la sortie du processus radio). |
| T74 | OK (2026-10-16 11:40-12:00) | **6 DS + 2 US sur le 9500 par le paquet** (Debian 13, Python 3.13, B210 Ekard seul sur son contrôleur USB 3) : en ligne en 40-80 s, RCC 6 canaux 290-330 MHz, 2 US ; U 0, L 0, O 0, marge TX 12-13 ms, 175/177 rafales décodées, MER 31 dB. Avertissement au démarrage : 334 Mo/s d'USB (> ~300). **Débit** (laptop derrière le modem, iperf3) : **DS 239 / 283 / 284 Mbit/s** (1 / 8 / 16 flux), **US 14,4 / 48,0** (1 / 8 flux), ping 74 ms au repos, 73 ms pendant un téléchargement, 170 ms (max 291) pendant un envoi. **4 rafales après 4 min de calme : 283 Mbit/s chaque fois, 0 blocage, 0 pause du ramasse-miettes, 0 perte de verrou.** Sur ~45 min : 14 underflows isolés « sans blocage du programme (retard côté USB / pilote) », y compris au repos, dont 2 suivis d'une perte de verrou d'un canal (revenu en quelques secondes) ; la carte son USB de la VM 103 n'est pas branchée, le B210 est seul sur le xHCI : reste l'USB à 334 Mo/s (> ~300) ou la charge de l'hôte Proxmox (VM 102, 103, 110 en marche). **Capacités du modem sur la page** (`cmts/modeminfo.py`) : du REG-REQ-MP (DOCSIS 3.0, 24 récepteurs DS, 8 émetteurs US, BPI+, IPv6, 0,16-5,12 Msym/s, 7 RCP de 2 à 24 canaux) et de son DHCP lu sur le pont (SAGEM F@ST3686, série, logiciel PC20_3.649.0 (firmware d'opérateur), boot 2.5.0beta8, composants ECM:EDVA:EROUTER, capacités de l'option 125 identiques). **Configuration depuis la page** (`cmts/webconfig.py`) : `us_target` −20 → −19 posté depuis la machine : fichier réécrit (commentaires gardés, `.bak`), CMTS arrêté proprement puis réexécuté (même PID pour systemd), modem en ligne 75 s plus tard, valeur relue ; puis retour à −20. Depuis le laptop : formulaire en lecture seule (`--status-edit auto`). |
| T75 | OK (2026-10-16 13:45-14:05) | **Speedtest par Internet à travers le modem** (6 DS + 2 US, 9500 ; le 9500 fait le NAT de 10.10.0.0/24, ligne mesurée en direct : 742 / 366 Mbit/s). Premier essai : 171-207 Mbit/s descendant, montant 7-30, et **un blocage d'émission de 72 ms, des blocs MAC à 13-27 ms, 3 canaux perdus** : ce que les iperf locaux ne montraient pas. Cause mesurée : l'interruption de la carte réseau (r8169, IRQ 134) et son traitement de réception (114 000 softirq NET_RX pendant un test) tombaient sur le CPU 3, un cœur temps réel du CMTS ; `--irq-herd` les envoyait vers le jumeau hyperthread du cœur USB, et l'i5-9500 n'a pas d'hyperthreading : rien n'était déplacé (« CPU de l'USB inconnu »). Interruption mise à la main sur le CPU 0 : 228 / 228 Mbit/s, aucun incident. **Corrigé** (`irq_target`) : sans SMT, le CPU USB lui-même (déjà laissé libre par `--cpus auto`) ; au redémarrage, 47 interruptions déplacées sur le CPU 0. Puis 3 speedtests : 205-215 Mbit/s descendant, montant 11-45 (aller-retour Internet de ~70 ms et peu de connexions : varie d'un essai à l'autre), latence 68-71 ms ; iperf 283 / 47 ; aucun blocage, aucune perte de verrou. |
| T76 | OK (2026-10-16 18:00-18:40) | **SDR débranché, arrêt et réglages de l'hôte.** Le 16/10 à 17:49 le B210 du 9500 a été débranché sous le service : UHD avorte dans le processus radio (`LIBUSB_ERROR_NO_DEVICE`), la MAC voit « processus radio arrêté »… et reste bloquée dans sa séquence d'arrêt ; le `systemctl stop` de 17:59 (SIGINT ignoré pendant l'arrêt) finit en SIGKILL après 30 s, rien n'est rétabli (47 interruptions laissées sur le CPU 0). **Cause reproduite sans matériel** avec la radio simulée (`SDR_CMTS_SDR_SIM`, `SDR_CMTS_SIM_UNPLUG_S`, `cmts/sdrdev.py SimRadio`) et `kill -USR1` sur la MAC (piles de tous les fils) : `RadioProcess.stop()` bloqué dans `multiprocessing.Event.set()`, qui attend l'accusé de chaque processus en attente, et la radio morte en attente ne le donne jamais. **Corrigé** : drapeau d'arrêt en mémoire partagée lu toutes les 100 ms. Radio perdue → arrêt en ~6 s, code 3 (`RADIO_LOST`) : le service la relance toutes les 15 s jusqu'au retour du SDR. **Réglages de l'hôte** (`cmts/hoststate.py`) : gouverneur, préférence d'énergie et affinité de chaque interruption notés dans /run avant tout changement, remis aux **valeurs par défaut du noyau** (gouverneur de démarrage, ou `powersave` pour intel_pstate si celui-ci n'est pas proposé ; préférence d'énergie du firmware ; `/proc/irq/default_smp_affinity`) à l'arrêt, par `ExecStopPost=sdr-cmts --restore-host` (même après SIGKILL) et au lancement suivant ; avant, une exécution tuée laissait le gouverneur `performance`, que le lancement suivant prenait pour l'original. Le 9500 remis à la main à l'affinité par défaut du noyau (gouverneur `performance` = défaut du noyau Proxmox). Tests : `test_sim_unplug.py` (arrêt seul en 11 s, code 3, aucune mémoire partagée laissée), `test_hoststate.py`. |
| T77 | OK (2026-10-16 19:30-20:45) | **CI GitHub Actions et /dev/shm.** Premier push sur https://github.com/TrusterBSW/SDR-CMTS : la CI échoue à l'étape des tests, journaux illisibles sans droits d'administrateur. Rejouée à l'identique dans un conteneur Ubuntu 24.04 (Python 3.12, NumPy 1.26, GNU Radio 3.10.9) : `test_sim_unplug.py` échoue, la radio meurt d'un **SIGBUS** dès son démarrage (pile par `PYTHONFAULTHANDLER`) : l'anneau d'échantillons montants (~110 Mo) dépasse le `/dev/shm` de 64 Mo de Docker, et une page écrite au-delà de la place du tmpfs tue le processus sans un mot. **Corrigé** : chaque mémoire partagée réservée à sa création (`posix_fallocate`, `usproc.create_shm`) → « /dev/shm trop petit : 111 Mo nécessaires…, 67 Mo libres (dans Docker : --shm-size=1g) », code 1, aucun segment laissé. Tests : `test_shm.py` ; `test_usproc.py` avec 0,15 s d'historique (il pousse 0,04 s) pour tenir dans 64 Mo ; `test_sim_unplug.py` sauté si `/dev/shm` est trop petit. Conteneur : 29 réussis, 2 sautés. `tests/run.py` publie la fin de la sortie d'un test en échec comme annotation GitHub (lisible sans droits). Grâce à elle, la vraie cause sur GitHub : `test_tapfeed.py` bloqué jusqu'au délai de 900 s. Il envoyait 300 trames dans une paire de sockets `SOCK_DGRAM` avant de les lire ; ces sockets s'arrêtent à `net.unix.max_dgram_qlen` datagrammes en attente (512 chez nous, moins sur les machines de GitHub). Passé en `SOCK_SEQPACKET` : la file restait limitée par la taille des tampons, plafonnée par `net.core.wmem_max` (208 Ko par défaut, ~90 trames ; 1 à 4 Mo chez nous) : envoi expiré sur GitHub. Le test met désormais en attente autant de trames que le noyau en accepte, sans jamais bloquer, et vérifie la limite de lot avec un tableau de lot plus petit (même code C) : passe avec nos réglages et avec les plafonds par défaut du noyau. |
| T78 | OK (2026-11-10) | **Paquet sans Python à la construction, trois distributions, version 0.1.0.** Un utilisateur sans NumPy n'arrivait pas à construire le paquet : `gen_man.py` charge le programme pour lire ses options, et `build-deb.sh` produisait quand même un `.deb` avec une page `man` vide. La page est maintenant gardée dans `man/sdr-cmts.1` (`gen_man.py --write`, `test_manpage.py` vérifie qu'elle est à jour) : la construction ne demande plus que `dpkg-deb`. `packaging/build-all-debs.sh` : construit dans un Debian 12 sans Python ni NumPy, puis installé et vérifié dans des conteneurs neufs de Debian 12, Debian 13 et Ubuntu 24.04 (`packaging/check-deb.sh`) : commande, 3 noyaux C compilés à l'installation et chargés, `man sdr-cmts`, service, `--restore-host`, démarrage complet sur la radio simulée et arrêt propre, `lintian` sans erreur (3 avertissements corrigés ensuite : longueur de lignes, `changelog.gz` d'un paquet natif). Le même déroulé dans `.github/workflows/packages.yml`, qui publie le paquet sur la page Releases à chaque étiquette `v*`. `install.sh` : installation en une ligne depuis `releases/` (somme SHA-256 vérifiée). |
| T27 | OK (2026-10-09 03:24) | US 2,56 Msym/s 16-QAM + DS 256-QAM : en ligne ; sous 45,9 Mbit/s DS, ~1000 trames/s montantes décodées (0 échec), ping 0 % de perte (134 ms moyen), U 0 L 0. Devenus les défauts. |
| T24 | OK (2026-10-09) | Émetteur descendant en C : J.83A identique au bit près au numpy (64/256-QAM, appels enchaînés, flux DOCSIS réel), GNU Radio et boucles 64/256 OK ; chaîne complète 4,5× le temps réel (2,5× avant) |
| T21 | en cours | 2,5 min en ligne, U 0 L 0, marge TX ~34 ms. À prolonger à 10 min ; tester `ping 10.10.0.10`. |

Joins aussi le **modèle exact du modem**, sa version de firmware et sa version DOCSIS.

---

## Étape 4 : provisionnement et enregistrement (`sdr_cmts.py --all-in-one`)

Même montage que l'étape 3. Ordre : lance le programme, puis allume le modem.

### T18 : tests sans radio
```bash
python3 tests/test_registration.py
python3 tests/test_provision_tap.py     # demande sudo (crée cmts0 si besoin)
```
- **Attendu :** `PASS` deux fois.

### T19 : bande accordée et DHCP
```bash
python3 sdr_cmts.py --all-in-one --pcap
```
- **Attendu au démarrage :** `[PONT] modems <-> cmts0`, puis `[PROV] cmts0 10.10.0.1/24 : DHCP …` et le contenu du fichier de config.
- **Après le ranging :** `[US] REQ SID 0x0001: … -> grant au MAP suivant`, puis `[PONT] ↑ DHCP DISCOVER de 24:7f:20:a8:38:b8 … [docsis3.0]`,
  `[DHCP] DISCOVER … → OFFER 10.10.0.10`, `[PONT] ↓ DHCP OFFER …`, puis REQUEST / ACK.
- **Plus de séries de 17 REQ** : une REQ, un grant, une trame.
- **Si le DISCOVER n'arrive pas** : regarder les lignes `[US] rafale … non décodée` dans les grants IUC 5/6 et garder le pcap.

### T20 : ToD, TFTP et enregistrement
- **Attendu :** `[ToD] heure envoyée`, `[TFTP] RRQ « cm.cfg »` puis `transféré`, puis `[REG] … REG-REQ` avec le détail des TLV,
  `[REG] REG-RSP ok … flux montant réf 1 SFID 1 SID 0x0001`, puis `[REG] … REG-ACK ok -> MODEM EN LIGNE`, et l'état `online`
  sur la ligne d'état.
- **À noter :** les capacités annoncées par le modem (TLV 5 du REG-REQ), toute ligne `!!`, et le journal d'événements du modem.

### T21 : stabilité en ligne (10 minutes)
- **Attendu :** le modem reste `online`, plus de réinitialisation toutes les 2 à 3 minutes (elles venaient de l'échec du DHCP),
  `U 0`. Le modem répond au ping : `ping 10.10.0.10`.

---

## Accélération C du récepteur montant

### T22 : tests sans radio
```bash
python3 tests/test_cdsp.py         # C = références Python, vitesses
python3 tests/test_real_bursts.py  # vraies rafales du Sagem : MER ~36 dB attendue (29 avant)
```
### T23 : banc, modem en ligne
```bash
python3 sdr_cmts.py --all-in-one
```
- **Attendu :** mêmes étapes qu'en T20, MER des rafales ~36 dB dans les lignes `[US]`, aucune ligne `[TX] !!` liée au décodage.
- **Puis, pour la latence :** `python3 sdr_cmts.py --all-in-one --tx-frames 128 --tx-queue 6` (latence descendante ~41 ms au lieu de ~75) ;
  garder ces valeurs par défaut seulement si `marge TX min` reste positive et `L 0` pendant 10 minutes.

### T24 : émetteur descendant en C (sans radio)
```bash
python3 tests/test_dsdsp.py; python3 tests/test_phy_vs_grdtv.py; python3 tests/test_loopback.py 64; python3 tests/test_loopback.py 256
python3 ds_tx.py --bench; python3 ds_tx.py --bench --qam 256      # attendu : > 4x le temps réel
```

### T25 : débit montant (concaténation, grants en avance)
```bash
python3 sdr_cmts.py --all-in-one          # réserves serrées par défaut
```
- Charger une page web et lancer un ping en même temps depuis le PC derrière la box.
- **Attendu :** les pings passent pendant le chargement ; sur la ligne d'état, `pont ↑` progresse bien au-delà de 18 trames/s
  sous charge, `concat` augmente, et `vides` reste une petite fraction des grants en avance.
- Comparer avec `--grant-ahead-ms 0` pour voir l'effet seul de la concaténation.

### T29 : agrégation de deux canaux descendants
```bash
python3 tests/test_bonding_tx.py                       # sans radio : chaque canal du signal composite démodulé seul
python3 sdr_cmts.py --all-in-one --ds-channels 2      # banc
```
- **Attendu :** `RCC : profil 0010001002, canaux 1@306 MHz, 2@314 MHz`, `REG-ACK ok`, `trafic unicast agrégé sur 2 canaux` ;
  sous charge, la ligne d'état montre la répartition `N/M par canal`. Un fast.com depuis le PC derrière la box doit dépasser
  ce que donnait un seul canal (~45 Mbit/s).
- Si `service partiel` : le modem n'a pas acquis le canal 2 ; relancer.

### T30–T32 : montant ATDMA (DOCSIS 2.0)
```bash
python3 tests/test_real_bursts.py        # inclut deux concaténations 64-QAM 5,12 Msym/s réelles (égaliseur)
python3 tests/test_merged_cluster.py     # rafale collée à la précédente : trouvée au début du grant
python3 sdr_cmts.py --all-in-one --us-mode atdma --us-mod 64qam --us-rate 32 --prov-args "--us-rate 20000000"
```
- **Attendu :** en ligne comme en TDMA ; ligne d'état `rafales N (décodées ≈N)`, MER modem ~25 dB (brute, avant égaliseur) ;
  aucune ligne `[TX] !!` ; `captures/bursts_ko/` vide ou presque.
- **Test de débit montant** (pas encore fait) : test d'envoi fast.com / speedtest depuis le PC derrière la box ; attendu
  bien au-delà des ~8 Mbit/s utiles du TDMA 16-QAM 2,56 (cm.cfg à 20 Mbit/s montant).
- Pour charger le descendant sans fausser le ping, envoyer la charge à l'eRouter (10.10.0.11), pas au modem.
